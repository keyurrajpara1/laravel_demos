<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    {{ __("You're logged in!") }}

                    <br /><br /><br />
                    All Notifications
                    @foreach(auth()->user()->notifications as $key => $notification)
                    <div class="bg-blue-300 p-3">
                        <strong>{{ $notification->data['name'] }}</strong> started following you !!!
                    </div>
                    @endforeach
                    
                    <br /><br /><br />
                    Unread Notifications
                    @foreach(auth()->user()->unreadnotifications as $key => $notification)
                    <div class="bg-blue-300 p-3">
                        <strong>{{ $notification->data['name'] }}</strong> started following you !!!
                        <a href="{{ route('mark-as-read', $notification->id) }}" class="p-2 bg-red-600 text-white rounded-lg">Mark as read</a>
                    </div>
                    @endforeach
                    
                    <br /><br /><br />
                    Read Notifications
                    @foreach(auth()->user()->readnotifications as $key => $notification)
                        <div class="bg-blue-300 p-3">
                            <strong>{{ $notification->data['name'] }}</strong> started following you !!!
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
