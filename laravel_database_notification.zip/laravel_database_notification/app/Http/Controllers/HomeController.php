<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Notifications\UserFollowNotification;
use App\Models\User;

class HomeController extends Controller
{
    public function index(){
        return view('welcome');
    }
    // http://localhost/laravel_database_notification/public/notify
    public function notify(){
        // lets say user follow

        if(auth()->user()){
            // First user follows authenticated user
            // $user = User::first();
            // auth()->user()->notify(new UserFollowNotification($user));

            // Fourth user follows authenticated user
            // $user = User::whereId(4)->first();
            // auth()->user()->notify(new UserFollowNotification($user));

            // Seventh user follows authenticated user
            // $user = User::whereId(7)->first();
            // auth()->user()->notify(new UserFollowNotification($user));
        }

        dd("Done");
    }
    public function markAsRead($id){
        // dd($id);
        if($id){
            auth()->user()->notifications->where('id', $id)->markAsRead();
        }
        return back();
    }
}
