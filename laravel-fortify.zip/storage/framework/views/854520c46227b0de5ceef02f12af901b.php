

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Two Factor Authentication')); ?></div>

                <div class="card-body">
                    <?php if(session('status') == "two-factor-authentication-disabled"): ?>
                        <div class="alert alert-success" role="alert">
                            Two factor Authentication has been disabled.
                        </div>
                    <?php endif; ?>

                    <?php if(session('status') == "two-factor-authentication-enabled"): ?>
                        <div class="alert alert-success" role="alert">
                            Two factor Authentication has been enabled.
                        </div>
                    <?php endif; ?>


                    <form method="POST" action="/user/two-factor-authentication">
                        <?php echo csrf_field(); ?>

                        <?php if(auth()->user()->two_factor_secret): ?>
                            <?php echo method_field('DElETE'); ?>

                            <div class="pb-5">
                                <?php echo auth()->user()->twoFactorQrCodeSvg(); ?>

                            </div>

                            <div>
                                <h3>Recovery Codes:</h3>

                                <ul>
                                    
                                    <?php $__currentLoopData = (array) (auth()->user()->recoveryCodes()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($code); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>

                            <button class="btn btn-danger">Disable</button>
                        <?php else: ?>
                            <button class="btn btn-primary">Enable</button>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp_php_8_2_12\htdocs\laravel-fortify\resources\views/home.blade.php ENDPATH**/ ?>