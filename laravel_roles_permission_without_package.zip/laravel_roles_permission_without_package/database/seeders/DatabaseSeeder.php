<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        /* User::factory()->create([
            'name' => 'Test User',
            'email' => 'test@example.com',
        ]); */

        /* \App\Models\User::factory()->create([
            'name' => 'Test User',
            'email' => 'test@example.com',
        ]);
        \App\Models\Role::create([
            'name' => 'Admin',
            'description' => 'Admin Role',
        ]);
        \App\Models\Role::create([
            'name' => 'User',
            'description' => 'User Role',
        ]);
        \App\Models\Permission::create([
            'name' => 'add_user',
            'description' => 'can add a new user',
        ]);
        \App\Models\Permission::create([
            'name' => 'view_user',
            'description' => 'can view the user information',
        ]); */

        /* \App\Models\User::factory()->create([
            'name' => 'Admin',
            'email' => 'admin@admin.com',
        ]);
        \App\Models\User::factory()->create([
            'name' => 'User',
            'email' => 'user@user.com',
        ]); */
    }
}
