<?php

use Illuminate\Support\Facades\Route;

use App\Models\{User, Role, Permission};

Route::get('/', function () {
    /* $admin = User::whereName('Admin')->first();
    // dd($admin->toArray());

    $adminRole = Role::whereName('Admin')->first();
    // dd($adminRole->toArray());

    $admin->roles()->attach($adminRole); */

    // --------------------------------

    /* $admin = User::whereName('Admin')->with('roles')->first();
    // dd($admin->toArray());
    if($admin->hasRole('Admin')){
        dd('Yes this user has admin role');
    }
    else{
        dd('No this user has not admin role');
    } */

    // --------------------------------
    // --------------------------------

    /* $user = User::whereName('User')->first();
    // dd($user->toArray());

    $userRole = Role::whereName('User')->first();
    // dd($userRole->toArray());

    $user->roles()->attach($userRole); */

    // --------------------------------

    /* $user = User::whereName('User')->with('roles')->first();
    // dd($user->toArray());
    if($user->hasRole('User')){
        dd('Yes this user has user role');
    }
    else{
        dd('No this user has not user role');
    } */

    // --------------------------------
    // --------------------------------

    // permissions
    /* $add_user_permission = Permission::where('name', 'add_user')->first();
    $adminRole = Role::whereName('Admin')->first();
    $adminRole->permissions()->attach($add_user_permission);
    dd($adminRole->permissions()); */

    /* $adminRole = Role::whereName('Admin')->with('permissions')->first();
    dd($adminRole->toArray()); */

    /* $view_user_permission = Permission::where('name', 'view_user')->first();
    $adminRole = Role::whereName('Admin')->first();
    $adminRole->permissions()->attach($view_user_permission);
    dd($adminRole->permissions()); */

    /* $adminRole = Role::whereName('Admin')->with('permissions')->first();
    dd($adminRole->toArray()); */

    // 

    /* $userRole = Role::whereName('User')->first();
    $view_user_permission = Permission::where('name', 'view_user')->first();
    $userRole->permissions()->attach($view_user_permission);
    dd($userRole->permissions()); */

    /* $users = User::select('id', 'name', 'email')
        //->with('roles.permissions')
        ->with([
            'roles:id,name',
            'roles.permissions:id,name',
        ])
        ->get();
    dd($users->toArray()); */

    return view('welcome');
});
