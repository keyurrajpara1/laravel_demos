<?php echo e($slot); ?>

<?php /**PATH D:\xampp_php_8_2_12\htdocs\laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>