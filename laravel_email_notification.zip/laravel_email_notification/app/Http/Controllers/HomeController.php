<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Notification;
use App\Notifications\WelcomeNotification;

class HomeController extends Controller
{
    public function index(){
        /* $user = User::first();
        Notification::send($user, new WelcomeNotification);
        dd("Done");
        return view('welcome'); */

        $blogPostData = [
            'title' => 'Post title',
            'slug' => 'post-slug'
        ];
        $users = User::get();
        foreach ($users as $key => $user) {
            // Notification::send($user, new WelcomeNotification($blogPostData));
            //or
            $user->notify(new WelcomeNotification($blogPostData));
        }
        dd("Done");
        return view('welcome');
    }
}
