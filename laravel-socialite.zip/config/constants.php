<?php
    return [
        'auth' => [
            'google' => [
                'client_id' => '653367896521-csr23sajeu6ri8vqgj9bfva0cl8tnvn8.apps.googleusercontent.com',
                'client_secret' => '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',
                'callback' => env('APP_URL')."/auth/google/callback" // http://127.0.0.1:8000/auth/google/callback
            ]
        ]
    ];
?>