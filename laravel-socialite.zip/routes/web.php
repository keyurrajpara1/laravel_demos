<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\Socialite\GoogleController, App\Http\Controllers\Auth\Socialite\FacebookController;

Route::get('/', function () {
    return view('welcome');
});

/* http://127.0.0.1:8000/auth/google
http://127.0.0.1:8000/auth/google/callback */
Route::prefix('auth')->name('auth.')->group(function () {
    Route::prefix('google')->name('google.')->controller(GoogleController::class)->group(function () {
        Route::get('/', 'redirectToProvider')->name('login');
        Route::get('/callback', 'handleProviderCallback')->name('callback');
    });

    Route::prefix('facebook')->name('facebook.')->controller(FacebookController::class)->group(function () {
        Route::get('/', 'redirectToProvider')->name('login');
        Route::get('/callback', 'handleProviderCallback')->name('callback');
    });
});

