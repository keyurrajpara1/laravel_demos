<?php
namespace App\Http\Controllers\Auth\Socialite;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request, Illuminate\Support\Facades\Auth, Illuminate\Support\Facades\Hash;
use Laravel\Socialite\Facades\Socialite;
use App\Models\User;
use Throwable, Exception;
use Illuminate\Support\Facades\Config;
class GoogleController extends Controller{
    public function redirectToProvider(Request $request){
        // echo route('auth.google.callback');exit;
        // echo url('auth/google/callback');exit;
        // $googleClientId = config('services.google.client_id');
        // $googleSecret = config('services.google.client_secret');
        // $googleRedirect = config('services.google.redirect');
        // dd($googleClientId, $googleSecret, $googleRedirect);
        // echo Config::get("services.google.client_id");exit;

        $provider = 'google';
        return Socialite::driver($provider)
            // ->scopes(['read:user', 'public_repo'])
            // ->setScopes(['read:user', 'public_repo'])
            // ->with(['hd' => 'example.com'])
            ->redirect();
    }
    public function _pre($array, $exit = 1){
        echo '<pre>';
        print_r($array);
        echo '</pre>';
        if ($exit == 1) {
            exit();
        }
    }
    public function handleProviderCallback(Request $request){
        try {
            $provider = 'google';
            $socialUser = Socialite::driver($provider)
                // ->stateless()
                ->user();
            $authProviderId = $socialUser->getId();

            $user = User::where('auth_provider_id', $authProviderId)->first();

            if($user){
                Auth::login($user);
            }
            else{
                $userData = User::create([
                    'name' => $socialUser->name,
                    'email' => $socialUser->email,
                    'password' => Hash::make('Password@1234'),
                    'auth_provider_id' => $authProviderId,
                    'auth_provider' => $provider,
                ]);

                if ($userData) {
                    Auth::login($userData);
                }
            }
            echo "dashboard page";
            exit;
            // return redirect()->route('dashboard');
        }
        catch (Throwable $throwable) {
            dd($throwable->getMessage());
        }
        catch (Exception $exception) {
            dd($exception->getMessage());
        }
    }
}
